import { useState, useEffect } from 'react';
import productsData from '../data/products.json';

export function useProducts() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [featured, setFeatured] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);

  useEffect(() => {
    try {
      // Simulate loading from API
      const timer = setTimeout(() => {
        setFeatured(productsData.featured);
        setProducts(productsData.products);
        setCategories(productsData.categories);
        setLoading(false);
      }, 500);

      return () => clearTimeout(timer);
    } catch (err) {
      setError('Failed to load products');
      setLoading(false);
    }
  }, []);

  return { featured, products, categories, loading, error };
}