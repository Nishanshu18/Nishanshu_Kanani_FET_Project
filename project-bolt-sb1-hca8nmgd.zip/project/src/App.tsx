import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeaturedProducts from './components/FeaturedProducts';
import ProductList from './components/ProductList';
import About from './components/About';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';
import { CartProvider } from './context/CartContext';

function App() {
  return (
    <CartProvider>
      <div className="min-h-screen bg-white">
        <Navbar />
        <Hero />
        <FeaturedProducts />
        <ProductList />
        <About />
        <Newsletter />
        <Footer />
      </div>
    </CartProvider>
  );
}

export default App;