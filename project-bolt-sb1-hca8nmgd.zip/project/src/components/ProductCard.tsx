import React, { useState } from 'react';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface Product {
  id: number;
  name: string;
  price: number;
  shortDescription: string;
  image: string;
  category: string;
}

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [isHovered, setIsHovered] = useState(false);
  const { dispatch } = useCart();

  const addToCart = () => {
    dispatch({ type: 'ADD_TO_CART', payload: product });
  };

  return (
    <div 
      className="bg-white rounded-lg overflow-hidden shadow-md transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative overflow-hidden h-64">
        <img 
          src={product.image} 
          alt={product.name} 
          className={`w-full h-full object-cover transition-transform duration-700 ${
            isHovered ? 'scale-110' : 'scale-100'
          }`}
        />
        <div className={`absolute inset-0 bg-black transition-opacity duration-300 ${
          isHovered ? 'bg-opacity-20' : 'bg-opacity-0'
        }`} />
        
        <button
          onClick={addToCart}
          className={`absolute bottom-4 right-4 p-3 rounded-full bg-[#D4AF37] text-white shadow-md hover:bg-[#C4A137] transition-all transform ${
            isHovered ? 'scale-100 opacity-100 translate-x-0' : 'scale-90 opacity-0 translate-x-4'
          }`}
        >
          <ShoppingCart size={20} />
        </button>
      </div>
      
      <div className="p-5">
        <div className="text-xs text-[#D4AF37] font-medium uppercase tracking-wider mb-2">
          {product.category}
        </div>
        <h3 className="font-medium text-lg text-[#3B2314] mb-2">{product.name}</h3>
        <p className="text-gray-600 text-sm mb-4">{product.shortDescription}</p>
        <div className="flex justify-between items-center">
          <span className="text-[#3B2314] font-bold">${product.price.toFixed(2)}</span>
          <button
            onClick={addToCart}
            className="text-sm font-medium text-[#5D4037] hover:text-[#D4AF37] transition-colors"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;