import React from 'react';
import ProductCard from './ProductCard';
import { useProducts } from '../hooks/useProducts';

const FeaturedProducts: React.FC = () => {
  const { featured, loading, error } = useProducts();

  if (loading) return <div className="text-center py-20">Loading...</div>;
  if (error) return <div className="text-center py-20">Error loading products</div>;

  return (
    <section id="featured" className="py-16 bg-[#FFF8E1]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-[#3B2314] mb-4">
            Featured Collections
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-gray-700">
            Our master chocolatiers have curated these exceptional collections for the most 
            discerning chocolate lovers. Indulge in our bestselling creations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center mt-12">
          <a 
            href="#products" 
            className="inline-flex items-center px-6 py-3 border-2 border-[#5D4037] text-[#3B2314] rounded-md hover:bg-[#5D4037] hover:text-white transition-colors font-medium"
          >
            View All Products
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-5 w-5 ml-2" 
              viewBox="0 0 20 20" 
              fill="currentColor"
            >
              <path 
                fillRule="evenodd" 
                d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" 
                clipRule="evenodd" 
              />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;