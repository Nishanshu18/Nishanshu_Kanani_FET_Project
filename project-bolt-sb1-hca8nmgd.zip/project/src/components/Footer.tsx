import React from 'react';
import { Facebook, Instagram, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-[#3B2314] text-white pt-12 pb-6">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-serif text-2xl font-bold mb-4">Chocoluxe</h3>
            <p className="text-gray-300 mb-4">
              Handcrafted premium chocolates for the discerning palate.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Shop</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">All Products</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">Truffles</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">Chocolate Bars</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">Gift Boxes</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">Corporate Gifts</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Information</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">About Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">Sustainability</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">Our Process</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">FAQ</a></li>
              <li><a href="#" className="text-gray-300 hover:text-[#D4AF37] transition-colors">Blog</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Contact</h4>
            <address className="not-italic text-gray-300 space-y-2">
              <p>123 Cocoa Lane</p>
              <p>Sweet Town, CH 12345</p>
              <p className="mt-4">info@chocoluxe.com</p>
              <p>+1 (555) 123-4567</p>
            </address>
          </div>
        </div>
        
        <div className="pt-8 mt-8 border-t border-gray-700 text-sm text-gray-400 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {new Date().getFullYear()} Chocoluxe. All rights reserved.</p>
          <div className="flex mt-4 md:mt-0 space-x-6">
            <a href="#" className="hover:text-[#D4AF37] transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-[#D4AF37] transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-[#D4AF37] transition-colors">Shipping Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;