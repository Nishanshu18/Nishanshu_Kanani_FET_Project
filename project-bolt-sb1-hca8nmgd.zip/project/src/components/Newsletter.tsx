import React, { useState } from 'react';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would submit to an API
    setIsSubmitted(true);
    setEmail('');
  };

  return (
    <section className="py-20 bg-[#FFF8E1]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-[#3B2314] mb-4">
            Join Our Chocolate Lovers Club
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-6"></div>
          <p className="mb-8 text-gray-700">
            Subscribe to our newsletter for exclusive offers, new collection announcements, 
            and chocolate appreciation tips. Plus, receive 15% off your first order!
          </p>
          
          {isSubmitted ? (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6">
              <p>Thank you for subscribing! Your welcome email with the discount code is on its way.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-grow px-4 py-3 rounded-md border-2 border-gray-300 focus:border-[#D4AF37] focus:outline-none"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-[#5D4037] text-white rounded-md hover:bg-[#3B2314] transition-colors whitespace-nowrap font-medium"
              >
                Subscribe
              </button>
            </form>
          )}
          
          <p className="mt-4 text-sm text-gray-500">
            We respect your privacy. Unsubscribe at any time.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;