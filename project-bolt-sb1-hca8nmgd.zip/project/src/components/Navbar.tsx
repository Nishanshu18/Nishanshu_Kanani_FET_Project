import React, { useState, useEffect } from 'react';
import { ShoppingCart, Menu, X } from 'lucide-react';
import { useCart } from '../context/CartContext';
import CartSidebar from './CartSidebar';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { state: cart } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-white text-[#3B2314] shadow-md py-3'
            : 'bg-transparent text-white py-6'
        }`}
      >
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex justify-between items-center">
            <a 
              href="#" 
              className="text-xl md:text-2xl font-serif font-bold tracking-wider"
            >
              Chocoluxe
            </a>

            {/* Desktop navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a 
                href="#" 
                className="font-medium hover:text-[#D4AF37] transition-colors"
              >
                Home
              </a>
              <a 
                href="#products" 
                className="font-medium hover:text-[#D4AF37] transition-colors"
              >
                Products
              </a>
              <a 
                href="#about" 
                className="font-medium hover:text-[#D4AF37] transition-colors"
              >
                Our Story
              </a>
              <a 
                href="#contact" 
                className="font-medium hover:text-[#D4AF37] transition-colors"
              >
                Contact
              </a>
              <button
                className="relative hover:text-[#D4AF37] transition-colors"
                onClick={() => setIsCartOpen(true)}
              >
                <ShoppingCart size={22} />
                {cart.totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#D4AF37] text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {cart.totalItems}
                  </span>
                )}
              </button>
            </div>

            {/* Mobile menu toggle */}
            <div className="flex items-center md:hidden space-x-4">
              <button
                className="relative hover:text-[#D4AF37] transition-colors"
                onClick={() => setIsCartOpen(true)}
              >
                <ShoppingCart size={22} />
                {cart.totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#D4AF37] text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {cart.totalItems}
                  </span>
                )}
              </button>
              <button
                className="hover:text-[#D4AF37] transition-colors"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile navigation */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-white pt-20 px-4 md:hidden">
          <div className="flex flex-col space-y-6 text-[#3B2314]">
            <a 
              href="#" 
              className="text-lg font-medium hover:text-[#D4AF37] transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </a>
            <a 
              href="#products" 
              className="text-lg font-medium hover:text-[#D4AF37] transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Products
            </a>
            <a 
              href="#about" 
              className="text-lg font-medium hover:text-[#D4AF37] transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Our Story
            </a>
            <a 
              href="#contact" 
              className="text-lg font-medium hover:text-[#D4AF37] transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact
            </a>
          </div>
        </div>
      )}

      {/* Cart sidebar */}
      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
};

export default Navbar;