import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-[#5D4037] text-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row gap-12 items-center">
          <div className="lg:w-1/2">
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-6">Our Story</h2>
            <div className="w-24 h-1 bg-[#D4AF37] mb-8"></div>
            <p className="mb-6 text-gray-200">
              Since 1987, Chocoluxe has been crafting exquisite chocolates using time-honored 
              techniques passed down through generations. Our journey began in a small kitchen 
              in Brussels, where our founder, Master Chocolatier Jean-Pierre Belgarde, 
              perfected his first truffle recipe.
            </p>
            <p className="mb-6 text-gray-200">
              Today, we continue to honor that legacy by sourcing the finest single-origin cocoa 
              beans and using only premium ingredients. Every piece of chocolate is handcrafted 
              with meticulous attention to detail, ensuring a perfect balance of flavors and textures.
            </p>
            <p className="text-gray-200">
              Our commitment extends beyond taste—we partner directly with cocoa farmers to ensure 
              ethical practices and sustainability throughout our supply chain, so you can indulge 
              with confidence.
            </p>
          </div>
          <div className="lg:w-1/2 grid grid-cols-2 gap-4">
            <div className="overflow-hidden rounded-lg">
              <img 
                src="https://images.pexels.com/photos/1055272/pexels-photo-1055272.jpeg" 
                alt="Chocolate making" 
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
              />
            </div>
            <div className="overflow-hidden rounded-lg">
              <img 
                src="https://images.pexels.com/photos/6206931/pexels-photo-6206931.jpeg" 
                alt="Cacao beans" 
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
              />
            </div>
            <div className="overflow-hidden rounded-lg">
              <img 
                src="https://images.pexels.com/photos/6208087/pexels-photo-6208087.jpeg" 
                alt="Chocolate process" 
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
              />
            </div>
            <div className="overflow-hidden rounded-lg">
              <img 
                src="https://images.pexels.com/photos/2693447/pexels-photo-2693447.jpeg" 
                alt="Chocolate selection" 
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;