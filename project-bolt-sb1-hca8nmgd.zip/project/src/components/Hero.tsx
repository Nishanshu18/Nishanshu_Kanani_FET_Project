import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen bg-black overflow-hidden">
      {/* Background image with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: "url('https://images.pexels.com/photos/918327/pexels-photo-918327.jpeg')",
          filter: "brightness(0.6)"
        }}
      />
      
      {/* Content container */}
      <div className="relative h-full flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="max-w-lg text-center">
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 tracking-tight">
            Indulge in <span className="text-[#D4AF37]">Excellence</span>
          </h1>
          <p className="text-white text-lg mb-8 opacity-90">
            Discover our handcrafted collection of premium chocolates, 
            made with the finest ingredients and artisanal techniques.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
            <a 
              href="#products" 
              className="px-8 py-3 bg-[#D4AF37] text-white rounded-md hover:bg-[#C4A137] transition-all transform hover:scale-105 font-medium"
            >
              Shop Now
            </a>
            <a 
              href="#about" 
              className="px-8 py-3 bg-transparent border-2 border-white text-white rounded-md hover:bg-white hover:text-[#3B2314] transition-all transform hover:scale-105 font-medium"
            >
              Our Story
            </a>
          </div>
        </div>
      </div>
      
      {/* Scroll down indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a href="#featured" className="text-white opacity-70 hover:opacity-100">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-6 w-6" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M19 14l-7 7m0 0l-7-7m7 7V3" 
            />
          </svg>
        </a>
      </div>
    </div>
  );
};

export default Hero;